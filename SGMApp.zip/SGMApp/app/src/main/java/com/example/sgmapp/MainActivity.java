package com.example.sgmapp;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;



public class MainActivity extends AppCompatActivity {

    //implements BottomNavigationView.OnNavigationItemSelectedListener
//    BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        bottomNavigationView = findViewById(R.id.bottomNavigationView);
//
//        bottomNavigationView.setOnNavigationItemSelectedListener(this);
//        bottomNavigationView.setSelectedItemId(R.id.home);

    }

//    DashboardActivity ds= new DashboardActivity();
//    WasteLevelActivity wl = new WasteLevelActivity();
//    NotificationsActivity ns = new NotificationsActivity();
//
//    @Override
//    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
//
//        switch (item.getItemId()) {
//            case R.id.home:
//                startActivity(new Intent(MainActivity.this,DashboardActivity.class));
//                return true;
//
//            case R.id.wasteLevel:
//                startActivity(new Intent(MainActivity.this,WasteLevelActivity.class));
//                return true;
//
//            case R.id.notifications:
//                startActivity(new Intent(MainActivity.this,NotificationsActivity.class));
//                return true;
//        }
//        return false;
   // }

}