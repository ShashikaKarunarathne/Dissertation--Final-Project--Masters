package com.example.sgmapp;

public class ReadWriteUserDetails {

    public String doB, gender, mobile;

    //constructor
    public ReadWriteUserDetails()
    {

    }

    public ReadWriteUserDetails(String textDoB, String textGender, String textMobile)
    {

        this.mobile = textMobile;


    }
}
