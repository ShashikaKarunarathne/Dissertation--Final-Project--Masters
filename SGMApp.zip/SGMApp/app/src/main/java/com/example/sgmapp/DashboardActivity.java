package com.example.sgmapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);


        TextView newdnewaccount = findViewById(R.id.userProfile);
        TextView newdnewaccount1 = findViewById(R.id.history);
        TextView newdnewaccount2 = findViewById(R.id.wasteLevel);
        TextView newdnewaccount3 = findViewById(R.id.analysis);
        TextView newdnewaccount4 = findViewById(R.id.notifications);
        TextView newdnewaccount5 = findViewById(R.id.contactUs);



        newdnewaccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(DashboardActivity.this,ProfileActivity.class));
            }
        });

        newdnewaccount1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(DashboardActivity.this,HistoryActivity.class));
            }
        });

        newdnewaccount2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(DashboardActivity.this,WasteLevelActivity.class));
            }
        });

        newdnewaccount3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(DashboardActivity.this,SummeryReportActivity.class));
            }
        });

        newdnewaccount4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(DashboardActivity.this,NotificationsActivity.class));
            }
        });

        newdnewaccount5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(DashboardActivity.this,ContactUsActivity.class));
            }
        });


    }
}