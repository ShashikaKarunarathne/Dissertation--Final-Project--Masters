package com.example.sgmapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.appcompat.app.AppCompatActivity;

import com.airbnb.lottie.LottieAnimationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class IntroductoryActivity extends AppCompatActivity {

    LottieAnimationView lottieAnimationView, lottieAnimationView1;

    FirebaseUser currentUser;
    private FirebaseAuth mAuth;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_introductory);



        lottieAnimationView=findViewById(R.id.lottie);
        lottieAnimationView1=findViewById(R.id.lottie1);
        lottieAnimationView.animate().translationX(1400).setDuration(1000).setStartDelay(4000);
        lottieAnimationView1.animate().translationX(1400).setDuration(1000).setStartDelay(4000);

        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(IntroductoryActivity.this , LoginActivity.class));
                finish();
            }
        },5000);




    }
}