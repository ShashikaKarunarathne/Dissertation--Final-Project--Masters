package com.example.sgmapp;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class ProfileActivity extends AppCompatActivity {

    public static final String TAG = "TAG";
    private TextView textView_show_mobile, textView_show_email,textView_show_full_name;
    private String name, email, mobile;
    private FirebaseAuth authProfile;
    FirebaseUser firebaseUser;
    String userID;
    FirebaseFirestore db = FirebaseFirestore.getInstance();



    //FirebaseUser user;
    //StorageReference storageReference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);


       // getSupportActionBar().setTitle("Home");

        textView_show_full_name=findViewById(R.id.textView_show_full_name);
        textView_show_email=findViewById(R.id.textView_show_email);
        textView_show_mobile=findViewById(R.id.textView_show_mobile);

        authProfile = FirebaseAuth.getInstance();
        firebaseUser= authProfile.getCurrentUser();

        if(firebaseUser==null)
        {
            Toast.makeText(ProfileActivity.this,"Something went wrong! User's details are not available at the moment",
            Toast.LENGTH_LONG).show();
        }
        else{
             showUserProfile(firebaseUser);
        }



    }

    private void showUserProfile(FirebaseUser firebaseUser ) {

        authProfile = FirebaseAuth.getInstance();
        firebaseUser = authProfile.getCurrentUser();
        userID = authProfile.getCurrentUser().getUid();
        DocumentReference documentReference = db.collection("users").document(userID);

    documentReference.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
        @Override
        public void onSuccess(DocumentSnapshot documentSnapshot) {

            if(documentSnapshot.exists())
            {
                String name = documentSnapshot.getString("fName");
                String email = documentSnapshot.getString("email");
                String phone = documentSnapshot.getString("phone");

                //Map<String, Object> map = documentSnapshot.getData();

                textView_show_full_name.setText(name);
                textView_show_email.setText(email);
                textView_show_mobile.setText(phone);
            }

        }
    }).addOnFailureListener(new OnFailureListener() {
        @Override
        public void onFailure(@NonNull Exception e) {

            Toast.makeText(ProfileActivity.this,e.toString(),Toast.LENGTH_SHORT).show();
        }
    });


//        String userID = firebaseUser.getUid();
//extract the  user reference from the database for "Users "
//        DatabaseReference referenceProfile = FirebaseDatabase.getInstance().getReference("users");
//        referenceProfile.child(userID).addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//
//                ReadWriteUserDetails readWriteUserDetails = snapshot.getValue(ReadWriteUserDetails.class);
//                if(readWriteUserDetails != null)
//                {
//                    fullname = firebaseUser.getDisplayName();
//                    email=firebaseUser.getEmail();
//                    mobile=readWriteUserDetails.mobile;
//
//                    textViewFullName.setText(fullname);
//                    textViewEmail.setText(email);
//                    textViewMobile.setText(mobile);
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//                Toast.makeText(ProfileActivity.this,"Something went wrong!",Toast.LENGTH_LONG).show();
//            }
//        });
    }
}